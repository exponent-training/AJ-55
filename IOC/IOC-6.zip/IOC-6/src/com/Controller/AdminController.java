package com.Controller;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.COnfig.AppConfig;
import com.Entity.Student;

public class AdminController {
	public static void main(String[] args) {

		ApplicationContext apc = new AnnotationConfigApplicationContext(AppConfig.class);
		Student st = apc.getBean("stu", Student.class);
		System.out.println(st.hashCode());

		Student st1 = apc.getBean("stu", Student.class);
		System.out.println(st1.hashCode());

	}
}
