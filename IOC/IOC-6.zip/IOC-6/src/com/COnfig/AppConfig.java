package com.COnfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.Entity.Student;

@Configuration
public class AppConfig {

	@Bean(name = "stu")
	@Scope(value = "prototype")
	public Student creatBeanForStudent() {

		Student st = new Student();
		st.setSid(100);
		st.setSname("Raju");

		return st;

	}
	
	

}
