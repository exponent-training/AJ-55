package com;

import javax.security.auth.callback.ConfirmationCallback;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Controlller {

	public static void main(String[] args) {

		// .1 resource , 2. Configuration , 3.Container calling , 4.get beans.
//		Resource res = new ClassPathResource("beans.xml");
//		BeanFactory beanfactory = new XmlBeanFactory(res);
		// container -> 1. reads xml config file.
//		                2. It Create Beans
//		                3. It manage Beans Life Cycle.
//		                4. After ending Beans work It will destory it.

		System.out.println("---------------------------------------------");
//		Student stu = beanfactory.getBean("st", Student.class);

		System.out.println("-------------------------------------");

//		ApplicaitonContext -> Conatiner.

//		ApplicationContext apc = new ClassPathXmlApplicationContext("beans.xml");
//		Student st1 = apc.getBean("st", Student.class);

	}
}
