package com;

public class Student {

	Student() {
		System.out.println("Constructor::called");
	}
}
