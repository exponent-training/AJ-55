package com;

import java.nio.file.FileSystemAlreadyExistsException;

import javax.security.auth.callback.ConfirmationCallback;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Controlller {

	public static void main(String[] args) {

		ApplicationContext apc = new ClassPathXmlApplicationContext("beans.xml");

		Employee employee1 = apc.getBean("emp", Employee.class);
		System.out.println(employee1.hashCode());

		Employee employee2 = apc.getBean("emp", Employee.class);
		System.out.println(employee2.hashCode());
		
		Employee employee3 = apc.getBean("emp", Employee.class);
		System.out.println(employee3.hashCode());
	}
}
