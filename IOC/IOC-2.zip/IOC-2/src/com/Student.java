package com;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Student {

	private int sid;

	private String sname;

	private List<Integer> sPhnumbers = new ArrayList<Integer>();

	private Set<Double> marks = new HashSet<Double>();

	private Map<Integer, String> addressWithPinCode = new HashMap<Integer, String>();

	/*
	 * public Student(int sid, String sname) { super(); this.sid = sid; this.sname =
	 * sname; }
	 */

	public int getSid() {
		return sid;
	}

	public List<Integer> getsPhnumbers() {
		return sPhnumbers;
	}

	public void setsPhnumbers(List<Integer> sPhnumbers) {
		this.sPhnumbers = sPhnumbers;
	}

	public Set<Double> getMarks() {
		return marks;
	}

	public void setMarks(Set<Double> marks) {
		this.marks = marks;
	}

	public Map<Integer, String> getAddressWithPinCode() {
		return addressWithPinCode;
	}

	public void setAddressWithPinCode(Map<Integer, String> addressWithPinCode) {
		this.addressWithPinCode = addressWithPinCode;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	@Override
	public String toString() {
		return "Student [sid=" + sid + ", sname=" + sname + ", sPhnumbers=" + sPhnumbers + ", marks=" + marks
				+ ", addressWithPinCode=" + addressWithPinCode + "]";
	}

}
