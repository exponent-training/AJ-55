package com.COnfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Scope;

import com.Entity.Controller;
import com.Entity.School;
import com.Entity.Service;
import com.Entity.Student;

@Configuration
public class AppConfig {

	@Bean(name = "sc1")
	@Primary
	public School getSchool() {

		School s = new School();
		s.setSid(1002);
		s.setSchoolName("PCCOE");

		return s;

	}

	@Bean(name = "sc2")
	public School getAnotherSchool() {

		School s = new School();
		s.setSid(1003);
		s.setSchoolName("PCET");

		return s;

	}

	@Bean(name = "stu")
	@Scope(value = "prototype")
	public Student creatBeanForStudent() {

		Student st = new Student();
		st.setSid(100);
		st.setSname("Raju");
//		st.setSchool(getSchool()); // manuall injection.

		return st;

	}

	@Bean(name = "servicebean")
	public Service service() {
		return new Service();
	}

	@Bean(name = "ctlbean")
	public Controller ctl() {

		Controller control = new Controller();
		control.setSs(service());

		return control;

	}

}
