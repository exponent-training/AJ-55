package com.Entity;

import org.springframework.stereotype.Component;

@Component
public class Service {

	public void serviceMethod() {
		System.out.println("Service method");
	}
}
