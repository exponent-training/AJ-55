package com.Entity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

import com.COnfig.AppConfig;

@Component
public class Controller {

	@Autowired
	private static Service ss;

	public static Service getSs() {
		return ss;
	}

	public static void setSs(Service ss) {
		Controller.ss = ss;
	}

	public static void main(String[] args) {

		ApplicationContext apc = new AnnotationConfigApplicationContext(AppConfig.class);
		Controller ctl = apc.getBean("ctlbean", Controller.class);
		ctl.ss.serviceMethod();
	}

}
