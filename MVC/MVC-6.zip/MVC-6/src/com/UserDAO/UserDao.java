package com.UserDAO;

import java.util.List;

import com.Entity.User;

public interface UserDao {

	void registerUserInDAO(User user);

	List<User> loginUserUsingDAO();

	List<User> getAllUserInDAO(String un, String ps);

	List<User> deleteUserInDAO(int id);
}
