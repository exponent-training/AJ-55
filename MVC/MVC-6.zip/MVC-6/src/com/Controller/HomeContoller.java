package com.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.Entity.User;
import com.UserService.UserServiceInterface;

@Controller
public class HomeContoller {

	@Autowired
	private UserServiceInterface us;

	@RequestMapping("/log")
	public String getCred(@RequestParam("un") String u, @RequestParam("ps") String p, Model model) {
		System.out.println("username :- " + u);
		System.out.println("Password :- " + p);

		User user = us.loginUser(u, p);

		if (user != null) {
			System.out.println(user);
			model.addAttribute("msg", user);
			return "Success";
		} else {
			System.out.println("Credential not Valid");
			model.addAttribute("msg", "Username Password Invalid");
			return "Login";
		}

	}

	@RequestMapping("/reg")
	public String RegisterUser(@ModelAttribute User user) {
		System.out.println(user);

//		hibernate -> 

//		Session session = sf.openSession();
//		session.save(user);
//		session.beginTransaction().commit();

		us.registerUser(user);

		System.out.println("User Registerd");
//web page Name Only.

		return "Login";
	}

	@RequestMapping("/getid")
	public String getCred(@RequestParam("uid") int id, @RequestParam("un") String u, @RequestParam("ps") String p,
			Model model) {
		System.out.println("username :- " + u);
		System.out.println("Password :- " + p);

		User user = us.loginwithUserID(id, u, p);

		if (user != null) {
			System.out.println(user);
			model.addAttribute("msg", user);
			return "Success";
		} else {
			System.out.println("Credential not Valid");
			model.addAttribute("msg", "Username Password Invalid");
			return "Login";
		}

	}

	@RequestMapping("/logAdmin")
	public String LogAdmin(@RequestParam("un") String u, @RequestParam("ps") String p, Model model) {
		System.out.println("username :- " + u);
		System.out.println("Password :- " + p);

		List<User> lu = us.getAllUser(u, p);

		if (lu != null) {
			System.out.println(lu);
			model.addAttribute("msg", lu);
			return "Success";
		} else {
			System.out.println("Credential not Valid");
			model.addAttribute("msg", "Username Password Invalid");
			return "LoginAdmin";
		}

	}

	@RequestMapping("/del")
	public String deleteUser(@RequestParam("uid") int id, Model model) {
		List<User> lu = us.deleteUserINService(id);
		model.addAttribute("msg", lu);
		return "Success";
	}

}
