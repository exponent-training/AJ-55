package com.UserService;

import java.util.List;

import com.Entity.User;

public interface UserServiceInterface {

	void registerUser(User user);

	User loginUser(String un, String ps);

	User loginwithUserID(int id, String un, String ps);

	List<User> getAllUser(String un, String ps);

	List<User> deleteUserINService(int id);

}
