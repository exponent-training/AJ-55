package com.UserService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.Entity.User;
import com.UserDAO.UserDao;

@Repository
public class UserServiceIMPL implements UserServiceInterface {

	@Autowired
	private UserDao ud;

	@Autowired
	private BCryptPasswordEncoder bc;

	@Override
	public void registerUser(User user) {

		System.out.println("I am in Service Layer");

		System.out.println("User :- " + user);

		String encode = bc.encode(user.getUpassword());
		System.out.println(encode);
		user.setUpassword(encode);
		ud.registerUserInDAO(user);

		// Buisness Logic layer -> Service Layer

	}

	@Override
	public User loginUser(String un, String ps) {
		System.out.println("I am in Service Layer");

		List<User> allUsers = ud.loginUserUsingDAO();

//		User user = allUsers.stream().filter(u -> u.getUname().equals(un) && u.getUpassword().equals(ps)).findFirst()
//				.get();

//		if (user != null) {
//			return user;
//		}

		boolean flag = false;
		for (User user : allUsers) {
			if (user.getUname().equals(un) && bc.matches(ps, user.getUpassword())) {
				flag = true;
				return user;
			}
		}

		return null;
	}

	@Override
	public User loginwithUserID(int id, String un, String ps) {

		System.out.println("I am in Service Layer");

		System.out.println(id);

		List<User> allUsers = ud.loginUserUsingDAO();

//		User user = allUsers.stream().filter(u -> u.getUname().equals(un) && u.getUpassword().equals(ps)).findFirst()
//				.get();

//		if (user != null) {
//			return user;
//		}

		boolean flag = false;
		for (User user : allUsers) {
			if (user.getUid() == id) {
				flag = true;
				return user;
			}
		}

		return null;
	}

	@Override
	public List<User> getAllUser(String un, String ps) {

		if (un.equals("admin") && ps.equals("admin123")) {
			List<User> allUserDetail = ud.getAllUserInDAO(un, ps);
			return allUserDetail;
		}

		return null;
	}

	@Override
	public List<User> deleteUserINService(int id) {

		// 1. check -> Id exist or not.

		return ud.deleteUserInDAO(id);

	}

}
