package com.UserDAO;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.Entity.User;

@Service
public class UserDaoIMPL implements UserDao {

	@Autowired
	private SessionFactory sf;

	@Override
	public void registerUserInDAO(User user) {

		System.out.println("I am in DAO Layer");
		System.out.println("User :- " + user);

		Session session = sf.openSession();
		session.save(user);
		session.beginTransaction().commit();
		System.out.println("User Registerd");

	}

	@Override
	public List<User> loginUserUsingDAO() {

		System.out.println("I am in DAO Layer");
		Session s = sf.openSession();
		Query query = s.createQuery("From User");
		List<User> listUser = query.getResultList();

		System.out.println(listUser);

		return listUser;
	}

}
