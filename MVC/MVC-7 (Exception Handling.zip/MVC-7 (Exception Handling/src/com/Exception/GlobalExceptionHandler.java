package com.Exception;

import org.springframework.core.annotation.Order;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
@Order(value = 1)
public class GlobalExceptionHandler {

	@ExceptionHandler(value = NullPointerException.class)
	public String NullPointerHandleMethod(Exception ex, Model model) {
		System.out.println(ex.getLocalizedMessage());
		model.addAttribute("msg", "Null Pointer occures");
		return "error";
	}
}
