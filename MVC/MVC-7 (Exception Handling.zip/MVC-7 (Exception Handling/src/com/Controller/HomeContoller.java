package com.Controller;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.Entity.User;
import com.UserService.UserServiceInterface;

@Controller
public class HomeContoller {

	@Autowired
	private UserServiceInterface us;

	

	@RequestMapping("/log")
	public String getCred(@RequestParam("un") String u, @RequestParam("ps") String p, Model model) {
		System.out.println("username :- " + u);
		System.out.println("Password :- " + p);

		User user = us.loginUser(u, p);

		String str = null;
		System.out.println(str.toUpperCase());

		if (user != null) {
			System.out.println(user);
			model.addAttribute("msg", user);
			return "Success";
		} else {
			System.out.println("Credential not Valid");
			model.addAttribute("msg", "Username Password Invalid");
			return "Login";
		}

	}

	@RequestMapping("/reg")
	public String RegisterUser(@ModelAttribute User user) {
		System.out.println(user);

//		hibernate -> 

//		Session session = sf.openSession();
//		session.save(user);
//		session.beginTransaction().commit();

		us.registerUser(user);

		System.out.println("User Registerd");
//web page Name Only.

		return "Login";
	}

}
