package com.UserService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.Entity.User;
import com.UserDAO.UserDao;

@Repository
public class UserServiceIMPL implements UserServiceInterface {

	@Autowired
	private UserDao ud;

	@Override
	public void registerUser(User user) {

		System.out.println("I am in Service Layer");

		System.out.println("User :- " + user);

		ud.registerUserInDAO(user);

		// Buisness Logic layer -> Service Layer

	}

	@Override
	public User loginUser(String un, String ps) {
		System.out.println("I am in Service Layer");

		List<User> allUsers = ud.loginUserUsingDAO();

//		User user = allUsers.stream().filter(u -> u.getUname().equals(un) && u.getUpassword().equals(ps)).findFirst()
//				.get();

//		if (user != null) {
//			return user;
//		}

		boolean flag = false;
		for (User user : allUsers) {
			if (user.getUname().equals(un) && user.getUpassword().equals(ps)) {
				flag = true;
				return user;
			}
		}

		return null;
	}

}
