package com.UserService;

import com.Entity.User;

public interface UserServiceInterface {

	void registerUser(User user);

	User loginUser(String un, String ps);

}
