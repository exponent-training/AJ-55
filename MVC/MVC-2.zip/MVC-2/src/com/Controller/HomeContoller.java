package com.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeContoller {

	@RequestMapping("/log")
	public void getCred() {

		System.out.println("Log Request Called:: Thanks");
	}

}
