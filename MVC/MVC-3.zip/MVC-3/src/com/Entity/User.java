package com.Entity;

public class User {

	private String uname;

	private String uaddress;

	private String upassword;

	private double usalary;

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getUaddress() {
		return uaddress;
	}

	public void setUaddress(String uaddress) {
		this.uaddress = uaddress;
	}

	public String getUpassword() {
		return upassword;
	}

	public void setUpassword(String upassword) {
		this.upassword = upassword;
	}

	public double getUsalary() {
		return usalary;
	}

	public void setUsalary(double usalary) {
		this.usalary = usalary;
	}

	@Override
	public String toString() {
		return "User [uname=" + uname + ", uaddress=" + uaddress + ", upassword=" + upassword + ", usalary=" + usalary
				+ "]";
	}

}
