package com.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.Entity.User;

@Controller
public class HomeContoller {

	@RequestMapping("/log")
	public void getCred(@RequestParam("un") String u, @RequestParam("ps") String p) {
		System.out.println("username :- " + u);
		System.out.println("Password :- " + p);
		System.out.println("Log Request Called:: Thanks");
	}

	@RequestMapping("/reg")
	public String RegisterUser(@ModelAttribute User user) {
		System.out.println(user);
		System.out.println("User Registerd");
//web page Name Only.

		return "Login";
	}

}
